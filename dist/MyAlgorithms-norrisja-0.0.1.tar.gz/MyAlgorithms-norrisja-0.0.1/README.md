# MyAlgorithms

This is a library containing my own personal implementations of different machine learning algorithms. This project is for continuing my own education in ML algos and OOD code as well as for implementation to some of my other projects. 